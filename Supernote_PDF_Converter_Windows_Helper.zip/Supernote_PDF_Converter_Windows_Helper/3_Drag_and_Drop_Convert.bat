@echo off
setlocal
cd /d "%~dp0"
title Supernote PDF Converter - Drag and drop convert

if not exist "note_to_pdf.py" (
    echo Cannot find note_to_pdf.py in this folder.
    pause
    exit /b 1
)
if not exist "output" mkdir "output"

where py >nul 2>nul
if %errorlevel%==0 (set PYTHON_CMD=py) else (set PYTHON_CMD=python)

if "%~1"=="" (
    echo Drag one or more .note files onto this batch file.
    echo Or use 2_Convert_Notes_to_PDF.bat to convert everything in the input folder.
    pause
    exit /b 0
)

:loop
if "%~1"=="" goto done
%PYTHON_CMD% note_to_pdf.py "%~1" --out "output"
shift
goto loop

:done
echo.
echo Finished. PDFs should be in the output folder.
pause
