Supernote PDF Converter - Windows Helper

1. Copy note_to_pdf.py into this folder.
2. Double-click 1_Install_Requirements.bat once.
3. Put Supernote .note files into the input folder.
4. Double-click 2_Convert_Notes_to_PDF.bat.
5. Open the output folder to find the PDFs.

Alternative: drag one or more .note files onto 3_Drag_and_Drop_Convert.bat.
