@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title Supernote PDF Converter - Convert notes to PDF

echo.
echo ==========================================================
echo  Supernote PDF Converter
echo ==========================================================
echo.

if not exist "note_to_pdf.py" (
    echo Cannot find note_to_pdf.py in this folder.
    echo.
    echo Please copy note_to_pdf.py into the same folder as this batch file.
    echo.
    pause
    exit /b 1
)

if not exist "input" mkdir "input"
if not exist "output" mkdir "output"

where py >nul 2>nul
if %errorlevel%==0 (
    set PYTHON_CMD=py
) else (
    set PYTHON_CMD=python
)

%PYTHON_CMD% --version >nul 2>nul
if errorlevel 1 (
    echo Python was not found.
    echo Run 1_Install_Requirements.bat first, or reinstall Python.
    echo.
    pause
    exit /b 1
)

set FOUND=0
for %%F in ("input\*.note") do (
    set FOUND=1
    echo.
    echo Converting: %%~nxF
    %PYTHON_CMD% note_to_pdf.py "%%F" --out "output"
)

if "%FOUND%"=="0" (
    echo No .note files were found in the input folder.
    echo.
    echo Open the input folder, copy your Supernote .note files into it,
    echo then run this file again.
    echo.
    pause
    exit /b 0
)

echo.
echo Finished.
echo Your PDFs should be in the output folder.
echo.
pause
