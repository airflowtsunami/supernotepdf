@echo off
setlocal
cd /d "%~dp0"
title Supernote PDF Converter - First-time setup

echo.
echo ==========================================================
echo  Supernote PDF Converter - First-time setup
echo ==========================================================
echo.
echo This installs the Python packages needed by the converter.
echo You only need to run this once on this computer.
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    set PYTHON_CMD=py
) else (
    set PYTHON_CMD=python
)

%PYTHON_CMD% --version >nul 2>nul
if errorlevel 1 (
    echo Python was not found.
    echo.
    echo Please install Python from https://www.python.org/downloads/windows/
    echo IMPORTANT: tick "Add python.exe to PATH" during installation.
    echo.
    pause
    exit /b 1
)

echo Using Python:
%PYTHON_CMD% --version
echo.

echo Upgrading pip...
%PYTHON_CMD% -m pip install --upgrade pip
if errorlevel 1 goto failed

echo.
echo Installing required packages...
%PYTHON_CMD% -m pip install supernotelib pypdf reportlab pillow
if errorlevel 1 goto failed

echo.
echo Setup complete.
echo You can now put .note files into the input folder and run:
echo 2_Convert_Notes_to_PDF.bat
echo.
pause
exit /b 0

:failed
echo.
echo Setup did not complete successfully.
echo Check that you are connected to the internet, then try again.
echo.
pause
exit /b 1
